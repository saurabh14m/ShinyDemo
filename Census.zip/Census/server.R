# server.R
library(maps)
source("helpers.R")
counties <- readRDS("data/counties.rds")

shinyServer(
  function(input, output) {
    
    output$map <- renderPlot({
      
      percent_map( # some arguments )
    })
    
  }
    )