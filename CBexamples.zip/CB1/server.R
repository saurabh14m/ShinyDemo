library(shiny)
shinyUI(pageWithSidebar(
  headerPanel("Minimal example"),
  sidebarPanel(
    # Shiny input function ??? Widgets Sliders etc
    # full list on CRAN pdf
    textInput(inputId = "comment",
              label = "Say something?",
              value = ""
    )
  ),
  mainPanel(
    h3("This is you saying it"), #HTML FUNCTION
    # Shiny output function
    textOutput("textDisplay")
  )
))