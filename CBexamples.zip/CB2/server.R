library(shiny)
shinyServer(function(input, output) {
  output$textDisplay <- renderTable({
    getMat = matrix(c(paste(
      #-----------------------------------#
      #Input 1 and 2
      input$checkGroup, collapse=','),
      class(input$checkGroup),
      input$boxInput, class(input$boxInput),
      #-----------------------------------#
      # Input 3 and 4
      as.character(as.Date(input$theDate,
                           origin = "1970-01- 01")), class(input$theDate),
      paste(as.character(as.Date(input$dateRange[1],
                                 origin = "1970-01-01")),
            as.character(as.Date(input$dateRange[2],
                                 origin = "1970- 01-01")), collapse = ','),
      class(input$dateRange),
      #-----------------------------------#
      # Inputs 5 to 9
      input$pickNumber, class(input$pickNumber),
      input$pickRadio, class(input$pickRadio),
      input$comboBox, class(input$comboBox),
      input$slider, class(input$slider),
      input$comment, class(input$comment)
    ), ncol=2, byrow = TRUE)
    colnames(getMat) = c("Value", "Class")
    getMat
  })
})